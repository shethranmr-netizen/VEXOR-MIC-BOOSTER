VEXOR MIC BOOSTER — Android Studio starter project

Open this folder in Android Studio, allow Gradle sync, connect your Android device, and press Run.
Minimum Android: 8.0 (API 26). Target SDK: 35.

Implemented in this prototype:
- VEXOR dark/cyan Jetpack Compose interface
- Microphone permission and live microphone input-level meter
- MP3 file picker using Android's system document picker
- MP3 local playback, pause/stop, and playback volume slider
- Voice-control sliders and presets (interface only)

Important limitations:
- Mic gain/bass/treble/clarity controls are currently UI placeholders; they do not yet process the captured mic stream.
- MP3 audio currently plays through the phone speaker. It is NOT mixed into or injected into WhatsApp/game microphone input.
- On a non-rooted Android phone, a regular third-party app cannot generally replace another app's microphone source system-wide. Android input-sharing rules can also silence one app's mic capture when a voice-communication app is using the microphone.
- Speaker playback may be picked up acoustically by the phone mic, but echo cancellation/noise suppression may remove it and quality is not guaranteed.

Next engineering stage:
1. Implement a real-time DSP engine for supported local monitoring/recording.
2. Test Android audio input sharing and device-specific routing on the exact Xiaomi/Redmi/POCO model.
3. Only claim WhatsApp/game transmission if verified on-device.

References:
https://developer.android.com/media/platform/sharing-audio-input
https://developer.android.com/reference/android/media/MediaPlayer
https://developer.android.com/reference/android/content/Intent#ACTION_OPEN_DOCUMENT
